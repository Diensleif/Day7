﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SF2022User06Lib
{
    public class Calculations
    {
        public string[] AvailablePeriods(TimeSpan[] startTimes, int[] durations,
            TimeSpan beginWorkingTime, TimeSpan endWorkingTime,
            int consultationTime)
        {
            if (startTimes.Length != durations.Length)
            {
                throw new ArgumentException("Кол-во startTimes и durations не совпадает");
            }

            if (beginWorkingTime > endWorkingTime)
            {
                throw new ArgumentException("Начало времени работы начинается позже конца времени работы");
            }

            if (consultationTime <= 0)
            {
                throw new ArgumentException("Время, отведенное на консультацию, не может быть нулевым или отрицательным");
            }

            if (durations.Any(x => x <= 0))
            {
                throw new ArgumentException("Значения durations не могут быть нулевыми или отрицательными");
            }

            List<string> results = new List<string>();

            TimeSpan aStart = beginWorkingTime;
            TimeSpan aEnd;

            while (true)
            {
                if (aStart.TotalMinutes + consultationTime > endWorkingTime.TotalMinutes)
                {
                    break;
                }

                aEnd = TimeSpan.FromMinutes(aStart.TotalMinutes + consultationTime);

                var contact = false;

                for (int i = 0; i < startTimes.Length; i++)
                {
                    TimeSpan bStart = startTimes[i];
                    TimeSpan bEnd = TimeSpan.FromMinutes(bStart.TotalMinutes + durations[i]);

                    if (Contact(aStart, aEnd, bStart, bEnd))
                    {
                        contact = true;
                        aStart = bEnd;
                        break;
                    }
                }

                if (!contact)
                {
                    results.Add($"{aStart.ToString("hh':'mm")}-{aEnd.ToString("hh':'mm")}");
                    aStart = aEnd;
                }
            }

            return results.ToArray();
        }

        public bool Contact(TimeSpan aStart, TimeSpan aEnd,
            TimeSpan bStart, TimeSpan bEnd)
        {
            if (aStart < bStart && aEnd > bStart)
            {
                return true;
            }

            if (aStart >= bStart && aStart < bEnd)
            {
                return true;
            }

            return false;
        }
    }
}
