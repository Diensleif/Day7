﻿using Microsoft.Win32;
using Shop.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Shop.Windows
{
    /// <summary>
    /// Логика взаимодействия для AddEditProductWindow.xaml
    /// </summary>
    public partial class AddEditProductWindow : Window
    {
        private Product _product;
        private Entities _entities;

        public AddEditProductWindow(Product product, Entities entities)
        {
            InitializeComponent();

            _product = product;
            _entities = entities;

            CategoryInput.ItemsSource = _entities.Category.ToList();
            CategoryInput.SelectedValuePath = "Id";
            CategoryInput.DisplayMemberPath = "Name";

            UnitInput.ItemsSource = _entities.Unit.ToList();
            UnitInput.SelectedValuePath = "Id";
            UnitInput.DisplayMemberPath = "Name";

            ProdiverInput.ItemsSource = _entities.Provider.ToList();
            ProdiverInput.SelectedValuePath = "Id";
            ProdiverInput.DisplayMemberPath = "Name";

            if (_product.Article != string.Empty)
            {
                Title = "Окно редактирования";

                ArticleInput.Text = _product.Article;
                NameInput.Text = _product.Name;
                DescriptionInput.Text = _product.Description;
                CategoryInput.Text = _product.Category.Name;
                UnitInput.Text = _product.Unit.Name;
                ProdiverInput.Text = _product.Provider.Name;
                CountInput.Text = _product.Count.ToString();
                PriceInput.Text = _product.Price.ToString();
                if (_product.Photo != string.Empty)
                {
                    PhotoOutput.Source = _product.PhotoView;
                }
            }
            else
            {
                Title = "Окно добавления";
            }
        }

        private void PhotoInput_Click(object sender, RoutedEventArgs e)
        {
            var openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog() == true)
            {
                PhotoOutput.Source = new BitmapImage(new Uri(openFileDialog.FileName));
            }
        }

        private void ApplyButton_Click(object sender, RoutedEventArgs e)
        {
            if (ArticleInput.Text == string.Empty ||
                NameInput.Text == string.Empty ||
                DescriptionInput.Text == string.Empty ||
                CategoryInput.Text == string.Empty ||
                UnitInput.Text == string.Empty ||
                ProdiverInput.Text == string.Empty ||
                CountInput.Text == string.Empty ||
                PriceInput.Text == string.Empty)
            {
                MessageBox.Show("Все поля обязательны для заполнения",
                    "Ошибка",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
                return;
            }

            _product.Article = ArticleInput.Text;
            _product.Name = NameInput.Text;
            _product.Description = DescriptionInput.Text;
            _product.CategoryId = (int)CategoryInput.SelectedValue;
            _product.UnitId = (int)UnitInput.SelectedValue;
            _product.ProviderId = (int)ProdiverInput.SelectedValue;
            _product.Count = Convert.ToInt32(CountInput.Text);
            _product.Price = Convert.ToDouble(PriceInput.Text);

            if (_product.Count <= 0 || _product.Price <= 0)
            {
                MessageBox.Show("Цена и кол-во должны быть больше нуля",
                    "Ошибка",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
                return;
            }

            if (PhotoOutput.Source != null)
            {
                var photoName = DateTime.Now.Ticks.ToString();
                var photoSource = Uri.UnescapeDataString(((BitmapImage)PhotoOutput.Source).UriSource.AbsolutePath);
                File.Copy(photoSource, $"{Environment.CurrentDirectory}\\Images\\{photoName}", true);
                _product.Photo = photoName;
            }

            if (Title == "Окно добавления")
            {
                _entities.Product.Add(_product);
            }

            _entities.SaveChanges();

            DialogResult = true;
        }

        private void DenyButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }

        private void CountInput_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (!Char.IsDigit(e.Text[0]))
            {
                e.Handled = true;
            }
        }

        private void PriceInput_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            try
            {
                Convert.ToDouble(PriceInput.Text + e.Text);
            }
            catch
            {
                e.Handled = true;
            }
        }
    }
}
