﻿using Shop.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Shop.Windows
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Entities _entities = new Entities();

        public MainWindow()
        {
            InitializeComponent();
        }

        private string _captcha = string.Empty;
        private Random _random = new Random();
        private string _source = "qwertyuiopasdfghjklzxcvbnm" + "qwertyuiopasdfghjklzxcvbnm".ToUpper() + "1234567890";

        private void GenerateCaptcha()
        {
            _captcha = string.Empty;
            CaptchaInput.Text = string.Empty;
            CaptchaCanvas.Children.Clear();

            for (var i = 0; i < 4; i++)
            {
                var letter = new TextBlock();

                letter.Text = _source[_random.Next(_source.Length)].ToString();
                _captcha += letter.Text;

                letter.FontSize = 32;
                letter.Margin = new Thickness(i * 64 + _random.Next(32), _random.Next(32), 0, 0);
                letter.Padding = new Thickness(0);

                CaptchaCanvas.Children.Add(letter);
            }

            for (var x = 0; x < CaptchaCanvas.Width; x++)
            {
                for (var y = 0; y < CaptchaCanvas.Height; y++)
                {
                    var noise = new Rectangle();

                    noise.Width = 1;
                    noise.Height = 1;

                    noise.Margin = new Thickness(x, y, 0, 0);

                    noise.Fill = new SolidColorBrush(Color.FromArgb(128,
                        (byte)_random.Next(256),
                        (byte)_random.Next(256),
                        (byte)_random.Next(256)));

                    CaptchaCanvas.Children.Add(noise);
                }
            }

            for (var i = 0; i < 8; i++)
            {
                var line = new Line();

                line.X1 = _random.Next((int)CaptchaCanvas.Width);
                line.X2 = _random.Next((int)CaptchaCanvas.Width);
                line.Y1 = _random.Next((int)CaptchaCanvas.Height);
                line.Y2 = _random.Next((int)CaptchaCanvas.Height);

                line.Stroke = new SolidColorBrush(Color.FromArgb(128,
                        (byte)_random.Next(256),
                        (byte)_random.Next(256),
                        (byte)_random.Next(256)));

                CaptchaCanvas.Children.Add(line);
            }
        }

        private void EnterButton_Click(object sender, RoutedEventArgs e)
        {
            if (_captcha != CaptchaInput.Text)
            {
                MessageBox.Show("Капча введена неверно\nСистема будет заблокирована на 10 секунд",
                    "Ошибка",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);

                Thread.Sleep(10000);

                MessageBox.Show("Система разблокирована",
                    "Уведомление",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);

                return;
            }

            var user = _entities.User.FirstOrDefault(x => x.Login == LoginInput.Text && x.Password == PasswordInput.Password);

            if (user == null)
            {
                MessageBox.Show("Неверный логин или пароль",
                    "Ошибка",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);

                GenerateCaptcha();
                CaptchaContainer.Visibility = Visibility.Visible;

                return;
            }

            var productWindow = new ProductWindow(user.Id);
            productWindow.Show();
            this.Close();
        }

        private void EnterAsGuestButton_Click(object sender, RoutedEventArgs e)
        {
            var productWindow = new ProductWindow(0);
            productWindow.Show();
            this.Close();
        }
    }
}
